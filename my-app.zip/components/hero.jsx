import Link from 'next/link'
import React from 'react'

function Hero() {
  return (
    <div className='w-full text-white text-center py-24'>
      <span className='text-6xl font-bold'>وب </span>
      <span className='text-6xl font-bold text-[violet]'>آریایی</span>
      <p className='text-2xl mt-5'>طراحی و توسعه وب سایت</p>
      <p className='text-2xl mt-3 px-4'>
        ما بهترین خدمات طراحی و توسعه وب سایت را ارائه می‌دهیم تا کسب و کار شما را به سطح بالاتری برسانیم.
        <br />
        با ما همراه باشید تا حضور آنلاین خود را تقویت کنید و به موفقیت‌های بیشتری دست یابید.
      </p>
      <div className='mt-12 flex justify-center gap-6 flex-wrap'>
        <Link href={'tel:+989126583961'}>
          <button className='bg-violet-600 hover:bg-violet-800 text-white font-bold py-3 px-6 rounded transition duration-300 text-2xl shadow-[10px_10px_20px_black] hover:shadow-[10px_10px_25px_black]'>
            تماس بگیرید
          </button>
        </Link>
        <Link href='/services'>
          <button className='bg-white text-black font-bold py-3 px-6 rounded transition duration-300 text-2xl shadow-[10px_10px_20px_black] hover:bg-gray-300'>
            خدمات ما
          </button>
        </Link>
      </div>
    </div>
  )
}

export default Hero
