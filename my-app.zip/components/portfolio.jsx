'use client'

import React from 'react'

const slides = [
  { title: 'سایت فروشگاهی', image: '/images/example.png' },
  { title: 'سایت نوبت‌دهی', image: '/images/nobatdehi-online.jpg' },
  { title: 'سایت شرکتی', image: '/images/company.jpg' },
  { title: 'سایت شخصی', image: '/images/personal.jpg' },
  { title: 'سایت آموزشی', image: '/images/amoozeshi.jpg' },
  { title: 'سایت خبری', image: '/images/news-site-1.jpg' },
  { title: 'سایت خدماتی', image: '/images/company.jpg' },
  { title: 'سایت پزشکی', image: '/images/medical-website-design.webp' },
  { title: 'سایت رزومه', image: '/images/resume.jpg' },
]

const PortfolioGrid = () => {
  return (
    <div className="w-full max-w-7xl mx-auto p-4 pb-10">
      <h2 className="text-center text-3xl font-bold mb-10 text-white">نمونه کارهای ما</h2>
      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        {slides.map((slide, index) => (
          <div
            key={index}
            className="border border-gray-300 rounded-xl overflow-hidden shadow-md bg-white/90 hover:shadow-xl transition-transform duration-300 hover:scale-105"
          >
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-4 flex flex-col gap-2">
              <h3 className="text-lg font-semibold text-black">{slide.title}</h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default PortfolioGrid
