import AboutUs from '@/components/abou'
import React from 'react'

function page() {
  return (
    <div>
      <AboutUs />
    </div>
  )
}

export default page
