import PortfolioPage from '@/components/portfolio'
import React from 'react'

function page() {
  return (
    <div>
      <PortfolioPage />
    </div>
  )
}

export default page
